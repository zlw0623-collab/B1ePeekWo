# train_all_yolov13_fusions.py
from ultralytics import RTDETR
import warnings
import os

warnings.filterwarnings('ignore')

print("🚀 rtdetr多模态一键训练")
print("="*50)

# 所有要训练的模型配置文件
model_configs = [
    ("早期融合", r"/root/autodl-tmp/mmdetr/improve_multimodal/rtdetr/rtdetr-resnet18-earlyfusion.yaml"),
    ("中期融合", r"/root/autodl-tmp/mmdetr/improve_multimodal/rtdetr/rtdetr-18-mid-MH.yaml"),
    ("中后期融合", r"/root/autodl-tmp/mmdetr/improve_multimodal/rtdetr/rt-detr-18-midlate-MM_LAE.yaml"),
    ("后期融合", r"/root/autodl-tmp/mmdetr/improve_multimodal/rtdetr/rtdetr-18-late-HMM_LAE.yaml")
]

print("\n🔍 检查配置文件:")
for name, config_path in model_configs:
    if os.path.exists(config_path):
        print(f"✅ {name}: {os.path.basename(config_path)}")
    else:
        print(f"❌ {name}: 文件不存在!")

print("\n📁 检查数据配置文件:")
if os.path.exists(r"data.yaml"):
    print("✅ data.yaml: 存在")
else:
    print("❌ data.yaml: 不存在! 请先创建数据配置文件")
    exit(1)

print("\n🚂 开始训练...")
print("="*50)

# 依次训练每个模型
for i, (model_name, config_path) in enumerate(model_configs, 1):
    print(f"\n📊 [{i}/{len(model_configs)}] 训练: {model_name}")
    print(f"📁 配置文件: {os.path.basename(config_path)}")
    
    if not os.path.exists(config_path):
        print(f"❌ 配置文件不存在，跳过")
        continue
    
    try:
        # 加载模型
        model = RTDETR(config_path)
        
        # 训练模型 - 使用完全相同的参数
        model.train(
            data=r"data.yaml",
            batch=12,
            imgsz=640,
            epochs=1,
            amp=False,
            workers=8,
            optimizer='SGD',
            close_mosaic=0,
            device='0'
        )
        
        print(f"✅ {model_name} 训练完成!")
        
    except Exception as e:
        print(f"❌ {model_name} 训练失败: {str(e)}")

print("\n🎉 所有模型训练完成!")
print("📁 模型保存在 runs/detect/ 目录下")