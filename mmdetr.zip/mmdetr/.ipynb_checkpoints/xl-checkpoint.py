# train_all_yolov13_fusions_with_cache_clean_fixed.py
from ultralytics import RTDETR
import warnings
import os
import glob
import shutil
import time
import gc
import torch

warnings.filterwarnings("ignore")

print("🚀 RT-DETR多模态一键训练 (带缓存清理和通道修复)")
print("=" * 70)

# AutoDL环境中的基础路径
BASE_PATH = "/root/autodl-tmp/mmdetr"
RUNS_DIR = os.path.join(BASE_PATH, "runs/detect")
DATA_CACHE_DIR = os.path.join(BASE_PATH, "final-w/labels")


# 清理缓存函数
def clean_all_cache():
    """清理所有缓存文件"""
    print("🧹 清理缓存...")

    # 1. 清理数据缓存
    if os.path.exists(DATA_CACHE_DIR):
        cache_files = glob.glob(os.path.join(DATA_CACHE_DIR, "*.cache"))
        for cache_file in cache_files:
            try:
                os.remove(cache_file)
                print(f"   ✅ 删除数据缓存: {os.path.basename(cache_file)}")
            except Exception as e:
                print(f"   ⚠️  无法删除 {cache_file}: {e}")

    # 2. 清理PyTorch和CUDA缓存
    try:
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            print("   ✅ 清理CUDA缓存")
    except:
        pass

    # 3. 清理临时文件
    temp_dirs = ["/tmp", "/var/tmp"]
    for temp_dir in temp_dirs:
        if os.path.exists(temp_dir):
            for item in os.listdir(temp_dir):
                if item.startswith("torch_") or item.startswith("ultralytics_") or item.startswith("mmdetr_"):
                    item_path = os.path.join(temp_dir, item)
                    try:
                        if os.path.isfile(item_path):
                            os.remove(item_path)
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)
                    except:
                        pass

    # 4. 等待一下确保清理完成
    time.sleep(2)
    print("✅ 缓存清理完成!")


# 修复YOLO的check_amp函数，避免通道数不匹配
def fix_yolo_amp_check():
    """修复YOLO的AMP检查，避免使用默认的3通道模型"""
    try:
        import ultralytics.utils.checks as checks
        original_check_amp = checks.check_amp

        def patched_check_amp(model):
            """修复的AMP检查函数"""
            try:
                # 尝试使用自定义的AMP检查逻辑
                device = next(model.parameters()).device
                im = torch.randn(1, 3, 640, 640, device=device)  # 使用3通道测试
                # 禁用梯度以节省内存
                with torch.no_grad():
                    model(im)
                return True
            except Exception as e:
                print(f"⚠️  AMP检查失败，将禁用AMP: {e}")
                return False

        # 应用补丁
        checks.check_amp = patched_check_amp
        print("✅ 已修复AMP检查函数")
    except Exception as e:
        print(f"⚠️  无法修复AMP检查: {e}")


# 每个模型：名字、yaml路径、专属训练参数（禁用AMP）
model_configs = [
    (
        "早期融合",
        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rtdetr-resnet18-earlyfusion.yaml"),
        dict(batch=16, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
    ),
#    (
#        "中期融合",
#        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rtdetr-18-mid-MH.yaml"),
#        dict(batch=20, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
#    ),
#    (
#        "中后期融合",
#        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rt-detr-18-midlate-MM_LAE.yaml"),
#        dict(batch=16, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
#    ),
#    (
#        "后期融合",
#        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rtdetr-18-late-HMM_LAE.yaml"),
#        dict(batch=24, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
#    ),
]

# 检查配置文件和数据文件
print(f"\n🔍 检查配置文件 (基础路径: {BASE_PATH}):")
for name, config_path, _ in model_configs:
    if os.path.exists(config_path):
        print(f"✅ {name}: {os.path.basename(config_path)}")
    else:
        print(f"❌ {name}: 文件不存在! 路径: {config_path}")
        raise SystemExit(1)

print("\n📁 检查数据配置文件:")
data_path = os.path.join(BASE_PATH, "data.yaml")
if os.path.exists(data_path):
    print(f"✅ data.yaml: 存在 ({data_path})")
else:
    print(f"❌ data.yaml: 不存在! 路径: {data_path}")
    raise SystemExit(1)

# 检查配置文件中的通道数设置
print("\n🔍 检查配置文件通道数设置:")
for name, config_path, _ in model_configs:
    if os.path.exists(config_path):
        try:
            import yaml

            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            ch_value = config.get('ch', '未设置')
            print(f"  {name}: ch={ch_value}")
        except:
            print(f"  {name}: 无法读取配置文件")

print(f"\n📂 运行目录: {RUNS_DIR}")
if not os.path.exists(RUNS_DIR):
    os.makedirs(RUNS_DIR, exist_ok=True)
    print("📂 创建运行目录")

# 训练前先清理一次缓存
print("\n🧹 训练前初始缓存清理...")
clean_all_cache()

# 修复AMP检查
print("\n🔧 修复AMP检查函数...")
fix_yolo_amp_check()

print("\n🚂 开始训练 (带权重继承和缓存清理)...")
print("=" * 70)


# 记录已存在的train文件夹，以便检测新创建的
def get_existing_train_folders():
    """获取当前存在的train文件夹列表"""
    if not os.path.exists(RUNS_DIR):
        return []

    train_folders = []
    for item in os.listdir(RUNS_DIR):
        item_path = os.path.join(RUNS_DIR, item)
        if os.path.isdir(item_path) and item.startswith("train"):
            train_folders.append(item)

    return train_folders


def get_latest_train_folder():
    """获取最新的train文件夹（按名称数字顺序）"""
    train_folders = get_existing_train_folders()
    if not train_folders:
        return None

    # 按文件夹名称的数字部分排序
    def get_folder_number(folder_name):
        if folder_name == "train":
            return 0
        try:
            # 处理 train1, train2, train10 等情况
            num_str = folder_name[5:]  # 去掉 "train"
            return int(num_str) if num_str else 0
        except:
            return -1

    # 按数字排序，数字越大表示越新
    train_folders.sort(key=get_folder_number, reverse=True)
    return os.path.join(RUNS_DIR, train_folders[0])


def find_weight_for_model(model_name, previous_weight_path=None):
    """为模型查找可用的权重文件"""

    # 如果有上个模型的权重，优先使用
    if previous_weight_path and os.path.exists(previous_weight_path):
        return previous_weight_path

    # 否则查找最新的训练文件夹中的权重
    latest_folder = get_latest_train_folder()
    if latest_folder:
        weights_dir = os.path.join(latest_folder, "weights")
        if os.path.exists(weights_dir):
            # 检查权重文件
            for weight_file in ["best.pt", "last.pt", "best_fp16.pt"]:
                weight_path = os.path.join(weights_dir, weight_file)
                if os.path.exists(weight_path):
                    print(f"📂 在 {os.path.basename(latest_folder)} 中找到权重: {weight_file}")
                    return weight_path

    # 如果都没有，返回None
    return None


# 存储上一个模型的权重路径
previous_weight_path = None
weight_history = []  # 记录所有模型权重路径
trained_models = []  # 记录已训练的模型

# 记录训练前的文件夹状态
initial_folders = get_existing_train_folders()
print(f"📁 训练前已存在的文件夹: {initial_folders}")

for i, (model_name, config_path, train_kwargs) in enumerate(model_configs, 1):
    print(f"\n{'=' * 70}")
    print(f"📊 [{i}/{len(model_configs)}] 准备训练: {model_name}")
    print(f"📁 配置文件: {os.path.basename(config_path)}")

    # 每次训练前都清理缓存
    print("🧹 训练前清理缓存...")
    clean_all_cache()

    # 查找可用的权重文件
    weight_to_use = find_weight_for_model(model_name, previous_weight_path)

    if weight_to_use:
        print(f"📥 使用权重: {os.path.basename(weight_to_use)}")
        print(f"📂 权重路径: {weight_to_use}")
    else:
        print("📥 未找到可用权重，将从头开始训练")

    if not os.path.exists(config_path):
        print("❌ 配置文件不存在，跳过")
        continue

    try:
        # 记录当前存在的文件夹（用于检测新创建的）
        before_folders = get_existing_train_folders()

        # 创建模型实例
        print(f"🔧 创建模型 {model_name}...")

        # 根据是否有权重来决定如何创建模型
        if weight_to_use and os.path.exists(weight_to_use):
            try:
                print(f"🔄 从权重文件创建模型: {os.path.basename(weight_to_use)}")
                # 从权重文件创建模型，它会自动继承权重中的架构
                model = RTDETR(weight_to_use)
                print("✅ 从权重成功创建模型")
            except Exception as e:
                print(f"⚠️  从权重创建模型失败: {e}")
                print("🔄 尝试从配置文件创建模型...")
                model = RTDETR(config_path)
                print("✅ 从配置文件创建模型")
        else:
            # 从头开始训练
            print("🔄 从头开始创建模型...")
            model = RTDETR(config_path)
            print("✅ 从头创建模型")

        # 关键：确保禁用AMP，避免通道数不匹配
        train_kwargs["amp"] = False

        # 添加内存优化参数
        train_kwargs["cache"] = False  # 禁用缓存
        train_kwargs["plots"] = True  # 禁用绘图，节省内存

        print(
            f"🔧 训练参数: batch={train_kwargs.get('batch')}, imgsz={train_kwargs.get('imgsz')}, amp={train_kwargs.get('amp')}")

        # 训练模型
        print(f"🚀 开始训练 {model_name}...")

        try:
            results = model.train(
                data=data_path,
                **train_kwargs
            )
        except Exception as train_error:
            print(f"❌ 训练过程中出错: {train_error}")
            # 尝试调整批量大小
            if "out of memory" in str(train_error) or "Killed" in str(train_error):
                print("🔄 内存不足，尝试减小批量大小...")
                train_kwargs["batch"] = max(8, train_kwargs["batch"] // 2)
                print(f"🔄 调整批量大小为: {train_kwargs['batch']}")

                # 重新训练
                results = model.train(
                    data=data_path,
                    **train_kwargs
                )
            else:
                raise train_error

        # 训练完成后，检测新创建的文件夹
        after_folders = get_existing_train_folders()
        new_folders = [f for f in after_folders if f not in before_folders]

        if new_folders:
            # 找到最新创建的文件夹
            new_folders.sort(key=lambda x: int(x[5:]) if x != "train" and x[5:].isdigit() else 0)
            latest_new_folder = new_folders[-1]
            new_folder_path = os.path.join(RUNS_DIR, latest_new_folder)

            print(f"📁 新创建的训练文件夹: {latest_new_folder}")

            # 在新文件夹中查找权重文件
            weights_dir = os.path.join(new_folder_path, "weights")
            if os.path.exists(weights_dir):
                # 等待一下确保权重文件保存完成
                time.sleep(3)

                # 查找权重文件
                weight_files = [f for f in os.listdir(weights_dir) if f.endswith('.pt')]

                # 优先使用best.pt
                best_weight = os.path.join(weights_dir, "best.pt")
                if os.path.exists(best_weight):
                    previous_weight_path = best_weight
                    weight_info = ("best.pt", best_weight)
                elif weight_files:
                    # 使用第一个找到的权重文件
                    first_weight = os.path.join(weights_dir, weight_files[0])
                    previous_weight_path = first_weight
                    weight_info = (weight_files[0], first_weight)
                else:
                    print(f"⚠️  在 {latest_new_folder}/weights 中未找到权重文件")
                    weight_info = None

                if weight_info:
                    weight_history.append((model_name, weight_info[1]))
                    print(f"✅ {model_name} 训练完成!")
                    print(f"💾 权重文件: {weight_info[0]}")
                    print(f"📂 完整路径: {weight_info[1]}")
                    print(f"📏 文件大小: {os.path.getsize(weight_info[1]) / 1024 / 1024:.1f} MB")

        trained_models.append(model_name)

        # 删除模型以释放内存
        if 'model' in locals():
            del model

        # 每个模型训练完成后清理缓存
        print("🧹 训练完成后清理缓存...")
        clean_all_cache()

    except Exception as e:
        print(f"❌ {model_name} 训练失败: {e}")
        import traceback

        traceback.print_exc()

        # 即使训练失败也要清理缓存
        print("🧹 训练失败后清理缓存...")
        clean_all_cache()

        # 即使训练失败，也尝试查找是否有权重文件生成
        after_folders = get_existing_train_folders()
        new_folders = [f for f in after_folders if f not in before_folders]
        if new_folders:
            print(f"⚠️  训练失败但检测到新文件夹: {new_folders}")

# 输出总结报告
print("\n" + "=" * 70)
print("📋 训练总结报告")
print("=" * 70)

print(f"\n✅ 成功训练的模型 ({len(trained_models)}/{len(model_configs)}):")
for i, model_name in enumerate(trained_models, 1):
    print(f"  {i}. {model_name}")

print(f"\n📁 权重继承历史:")
if weight_history:
    for i, (model_name, weight_path) in enumerate(weight_history):
        if weight_path and os.path.exists(weight_path):
            folder_name = os.path.basename(os.path.dirname(os.path.dirname(weight_path)))
            weight_file = os.path.basename(weight_path)
            print(f"  {i + 1}. {model_name}: {folder_name}/weights/{weight_file}")
        else:
            print(f"  {i + 1}. {model_name}: 无可用权重")
else:
    print("  ❌ 没有权重历史记录")

print(f"\n📂 所有训练记录保存在: {RUNS_DIR}")
if weight_history:
    last_weight = weight_history[-1][1]
    if os.path.exists(last_weight):
        print(f"📊 最终权重文件: {last_weight}")
        print(f"📦 文件大小: {os.path.getsize(last_weight) / 1024 / 1024:.1f} MB")

# 列出所有训练文件夹
print(f"\n📁 当前训练文件夹列表:")
train_folders = get_existing_train_folders()
train_folders.sort(key=lambda x: int(x[5:]) if x != "train" and x[5:].isdigit() else 0)
for folder in train_folders:
    folder_path = os.path.join(RUNS_DIR, folder)
    weights_dir = os.path.join(folder_path, "weights")
    if os.path.exists(weights_dir):
        weight_files = [f for f in os.listdir(weights_dir) if f.endswith('.pt')]
        print(f"  {folder}: {len(weight_files)} 个权重文件")
    else:
        print(f"  {folder}: 无权重文件")

print("\n🎉 训练流程完成!")