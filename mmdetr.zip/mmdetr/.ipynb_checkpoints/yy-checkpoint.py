from ultralytics import RTDETR
from pathlib import Path
import ultralytics

WEIGHTS = Path("/root/autodl-tmp/mmdetr/runs/v8.pt")

# IMPORTANT: for your custom multimodal loader, use YZ/images as source
SOURCE_DIR = Path("/root/autodl-tmp/mmdetr/YZZ/images")

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff", ".heic", ".dng", ".mpo", ".pfm"}

def count_images(folder: Path) -> int:
    if not folder.exists():
        return 0
    return sum(1 for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in IMG_EXTS)

if __name__ == "__main__":
    print("[info] ultralytics loaded from:", ultralytics.__file__)
    print("[info] weights:", WEIGHTS)
    print("[info] source:", SOURCE_DIR)

    if not WEIGHTS.exists():
        raise FileNotFoundError(f"Weight file not found: {WEIGHTS}")

    n = count_images(SOURCE_DIR)
    if n == 0:
        raise FileNotFoundError(f"No images found in {SOURCE_DIR} (supported: {sorted(IMG_EXTS)})")
    print(f"[check] found {n} images in {SOURCE_DIR}")

    model = RTDETR(str(WEIGHTS))
    model.predict(
        source=str(SOURCE_DIR),
        imgsz=640,
        save=True,
        device=0,
        project="detect",
        name="yz",
    )
