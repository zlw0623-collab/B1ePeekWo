from ultralytics import RTDETR

# Load a model
model = RTDETR('/root/autodl-tmp/mmdetr/runs/best.pt')
# Run batched inference on a list of images
model.predict("/root/autodl-tmp/mmdetr/YZ",
              imgsz=640,
              save=True,
              device=0,
              project='detect/spot-CGLGV',
              name='valB-detect',
              )
#D:\deep learning\snu77 RT-DETR\datasets\\11data\images\\val\\20.jpg
#D:\deep learning\snu77 RT-DETR\datasets\\11data\images\\train\mirror_20.jpg
#"D:\deep learning\snu77 RT-DETR\datasets\11data\images\val\mirror_12.jpg"
#Part2runs/rtdetr-r18/exp2/weights/best.pt
#P2runs/new-data-emo/exp2/weights/best.pt
#P2runs/origin-data-CG-rtdetr/exp2/weights/best.pt
#P2runs/origin-data-Faster-rtdetr/exp/weights/best.pt
#P2runs/origin-data-rtdetr-l-mpdiou/exp/weights/best.pt