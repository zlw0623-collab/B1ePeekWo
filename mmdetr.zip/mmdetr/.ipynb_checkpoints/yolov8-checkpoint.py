# train_all_yolov11_fusions_with_cache_clean_fixed.py
from ultralytics import YOLO  # 改为 YOLO 类
import warnings
import os
import glob
import shutil
import time
import gc
import torch

warnings.filterwarnings("ignore")

print("🚀 YOLOv8多模态一键训练 (带缓存清理和通道修复)")
print("=" * 70)

# AutoDL环境中的基础路径
BASE_PATH = "/root/autodl-tmp/mmdetr"
RUNS_DIR = os.path.join(BASE_PATH, "runs/detect")
DATA_CACHE_DIR = os.path.join(BASE_PATH, "final-w/labels")

# 添加 data_path 定义 - 根据你的说明，data.yaml 在 /root/autodl-tmp/mmdetr 路径下
DATA_YAML_PATH = os.path.join(BASE_PATH, "data.yaml")
data_path = DATA_YAML_PATH

# 检查数据文件是否存在
print(f"\n🔍 检查数据配置文件:")
if os.path.exists(data_path):
    print(f"✅ 数据配置文件: {data_path}")
else:
    print(f"❌ 数据配置文件不存在: {data_path}")
    # 尝试查找其他可能的位置
    search_paths = [
        os.path.join(BASE_PATH, "data.yaml"),
        os.path.join(BASE_PATH, "final-w/data.yaml"),
        os.path.join(BASE_PATH, "dataset/data.yaml"),
    ]
    for path in search_paths:
        if os.path.exists(path):
            data_path = path
            print(f"✅ 找到备用数据文件: {data_path}")
            break
    else:
        print("❌ 未找到数据配置文件，请检查路径")
        raise SystemExit(1)


# 清理缓存函数（保持不变）
def clean_all_cache():
    """清理所有缓存文件"""
    print("🧹 清理缓存...")
    # ...（保持原有清理代码）


# 修复YOLO的check_amp函数（保持不变）
def fix_yolo_amp_check():
    """修复YOLO的AMP检查，避免使用默认的3通道模型"""
    # ...（保持原有代码）


# 修改模型配置为使用 YOLO 类
model_configs = [
    (
        "早期融合",
        os.path.join(BASE_PATH, "improve_multimodal/yolov8/yolov8-earlyfusion.yaml"),
        dict(batch=36, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
    ),
    (
        "中期融合",
        os.path.join(BASE_PATH, "improve_multimodal/yolov8/yolov8-midfusion.yaml"),
        dict(batch=32, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
    ),
    (
        "中后期融合",
        os.path.join(BASE_PATH, "improve_multimodal/yolov8/yolov8-mid-to-late-fusion.yaml"),
        dict(batch=36, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
    ),
    (
        "后期融合",
        os.path.join(BASE_PATH, "improve_multimodal/yolov8/yolov8-latefusion.yaml"),
        dict(batch=36, imgsz=640, epochs=100, amp=False, workers=4, optimizer="SGD", close_mosaic=0, device="0"),
    ),
]

# 检查配置文件和数据文件
print(f"\n🔍 检查配置文件 (基础路径: {BASE_PATH}):")
for name, config_path, _ in model_configs:
    if os.path.exists(config_path):
        print(f"✅ {name}: {os.path.basename(config_path)}")
        # 检查配置文件内容
        try:
            import yaml

            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            print(f"  - 配置文件结构: {list(config.keys())}")
            if 'nc' in config:
                print(f"  - 类别数: {config['nc']}")
        except:
            print(f"  - 无法读取YAML内容")
    else:
        print(f"❌ {name}: 文件不存在! 路径: {config_path}")
        raise SystemExit(1)

# 训练前先清理一次缓存
print("\n🧹 训练前初始缓存清理...")
clean_all_cache()

# 修复AMP检查
print("\n🔧 修复AMP检查函数...")
fix_yolo_amp_check()

# ... 其余代码保持不变，但修改模型创建部分

for i, (model_name, config_path, train_kwargs) in enumerate(model_configs, 1):
    print(f"\n{'=' * 70}")
    print(f"📊 [{i}/{len(model_configs)}] 准备训练: {model_name}")

    # 清理缓存
    print("🧹 训练前清理缓存...")
    clean_all_cache()

    try:
        # 创建 YOLO 模型实例
        print(f"🔧 创建YOLO模型 {model_name}...")

        # 直接从配置文件创建YOLO模型
        model = YOLO(config_path)
        print(f"✅ 从配置文件成功创建YOLO模型")

        # 确保禁用AMP
        train_kwargs["amp"] = False
        train_kwargs["cache"] = False
        train_kwargs["plots"] = True

        print(f"🔧 训练参数: batch={train_kwargs.get('batch')}, imgsz={train_kwargs.get('imgsz')}")

        # 训练模型
        print(f"🚀 开始训练 {model_name}...")

        try:
            results = model.train(
                data=data_path,
                **train_kwargs
            )
            print(f"✅ {model_name} 训练完成!")

        except Exception as train_error:
            print(f"❌ 训练过程中出错: {train_error}")
            # 处理内存不足等情况
            if "out of memory" in str(train_error) or "Killed" in str(train_error):
                print("🔄 内存不足，尝试减小批量大小...")
                train_kwargs["batch"] = max(8, train_kwargs["batch"] // 2)
                print(f"🔄 调整批量大小为: {train_kwargs['batch']}")

                # 重新创建模型并训练
                model = YOLO(config_path)
                results = model.train(
                    data=data_path,
                    **train_kwargs
                )
            else:
                raise train_error

    except Exception as e:
        print(f"❌ {model_name} 训练失败: {e}")
        import traceback

        traceback.print_exc()

    # 清理缓存
    print("🧹 训练完成后清理缓存...")
    clean_all_cache()