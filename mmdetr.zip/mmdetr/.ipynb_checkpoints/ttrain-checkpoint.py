# train_all_yolov13_fusions_with_weight_inheritance_autodl_v4.py
from ultralytics import RTDETR
import warnings
import os
import glob
import shutil
import time

warnings.filterwarnings("ignore")

print("🚀 RT-DETR多模态一键训练 (AutoDL权重继承版 V4)")
print("=" * 70)

# AutoDL环境中的基础路径
BASE_PATH = "/root/autodl-tmp/mmdetr"
RUNS_DIR = os.path.join(BASE_PATH, "runs/detect")

# 每个模型：名字、yaml路径、专属训练参数
model_configs = [
    (
        "早期融合",
        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rtdetr-resnet18-earlyfusion.yaml"),
        dict(batch=20, imgsz=640, epochs=1, amp=True, workers=8, optimizer="SGD", close_mosaic=0, device="0"),
    ),
    (
        "中期融合",
        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rtdetr-18-mid-MH.yaml"),
        dict(batch=24, imgsz=640, epochs=1, amp=True, workers=8, optimizer="SGD", close_mosaic=0, device="0"),
    ),
    (
        "中后期融合",
        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rt-detr-18-midlate-MM_LAE.yaml"),
        dict(batch=20, imgsz=640, epochs=1, amp=True, workers=8, optimizer="SGD", close_mosaic=0, device="0"),
    ),
    (
       "后期融合",
        os.path.join(BASE_PATH, "improve_multimodal/rtdetr/rtdetr-18-late-HMM_LAE.yaml"),
        dict(batch=40, imgsz=640, epochs=1, amp=True, workers=8, optimizer="SGD", close_mosaic=0, device="0"),
    ),
]

# 检查配置文件和数据文件
print(f"\n🔍 检查配置文件 (基础路径: {BASE_PATH}):")
for name, config_path, _ in model_configs:
    if os.path.exists(config_path):
        print(f"✅ {name}: {os.path.basename(config_path)}")
    else:
        print(f"❌ {name}: 文件不存在! 路径: {config_path}")
        raise SystemExit(1)

print("\n📁 检查数据配置文件:")
data_path = os.path.join(BASE_PATH, "data.yaml")
if os.path.exists(data_path):
    print(f"✅ data.yaml: 存在 ({data_path})")
else:
    print(f"❌ data.yaml: 不存在! 路径: {data_path}")
    raise SystemExit(1)

# 检查数据配置文件内容，确认输入通道数
try:
    import yaml
    with open(data_path, 'r') as f:
        data_config = yaml.safe_load(f)
    print(f"📊 数据配置: {data_config.get('nc', '未知')} 个类别")
except:
    print("⚠️  无法读取数据配置文件")

print(f"\n📂 运行目录: {RUNS_DIR}")
if not os.path.exists(RUNS_DIR):
    os.makedirs(RUNS_DIR, exist_ok=True)
    print("📂 创建运行目录")

print("\n🚂 开始训练 (带权重继承)...")
print("=" * 70)

# 记录已存在的train文件夹，以便检测新创建的
def get_existing_train_folders():
    """获取当前存在的train文件夹列表"""
    if not os.path.exists(RUNS_DIR):
        return []
    
    train_folders = []
    for item in os.listdir(RUNS_DIR):
        item_path = os.path.join(RUNS_DIR, item)
        if os.path.isdir(item_path) and item.startswith("train"):
            train_folders.append(item)
    
    return train_folders

def get_latest_train_folder():
    """获取最新的train文件夹（按名称数字顺序）"""
    train_folders = get_existing_train_folders()
    if not train_folders:
        return None
    
    # 按文件夹名称的数字部分排序
    def get_folder_number(folder_name):
        if folder_name == "train":
            return 0
        try:
            # 处理 train1, train2, train10 等情况
            num_str = folder_name[5:]  # 去掉 "train"
            return int(num_str) if num_str else 0
        except:
            return -1
    
    # 按数字排序，数字越大表示越新
    train_folders.sort(key=get_folder_number, reverse=True)
    return os.path.join(RUNS_DIR, train_folders[0])

def find_weight_for_model(model_name, previous_weight_path=None):
    """为模型查找可用的权重文件"""
    
    # 如果有上个模型的权重，优先使用
    if previous_weight_path and os.path.exists(previous_weight_path):
        return previous_weight_path
    
    # 否则查找最新的训练文件夹中的权重
    latest_folder = get_latest_train_folder()
    if latest_folder:
        weights_dir = os.path.join(latest_folder, "weights")
        if os.path.exists(weights_dir):
            # 检查权重文件
            for weight_file in ["best.pt", "last.pt", "best_fp16.pt"]:
                weight_path = os.path.join(weights_dir, weight_file)
                if os.path.exists(weight_path):
                    print(f"📂 在 {os.path.basename(latest_folder)} 中找到权重: {weight_file}")
                    return weight_path
    
    # 如果都没有，返回None
    return None

# 存储上一个模型的权重路径
previous_weight_path = None
weight_history = []  # 记录所有模型权重路径
trained_models = []  # 记录已训练的模型

# 记录训练前的文件夹状态
initial_folders = get_existing_train_folders()
print(f"📁 训练前已存在的文件夹: {initial_folders}")

# 重要：检查是否需要6通道输入
# 根据你的数据，如果输入是6通道（比如RGB+红外），需要确保模型支持
# 从错误信息看，输入是[1,6,256,256]，说明数据是6通道
# 多模态融合模型应该已经处理了6通道输入，但可能需要特殊设置

for i, (model_name, config_path, train_kwargs) in enumerate(model_configs, 1):
    print(f"\n📊 [{i}/{len(model_configs)}] 准备训练: {model_name}")
    print(f"📁 配置文件: {os.path.basename(config_path)}")
    
    # 查找可用的权重文件
    weight_to_use = find_weight_for_model(model_name, previous_weight_path)
    
    if weight_to_use:
        print(f"📥 使用权重: {os.path.basename(weight_to_use)}")
        print(f"📂 权重路径: {weight_to_use}")
        # 注意：多模态模型可能已经配置了6通道输入
        # 从权重加载时，会自动使用正确的输入通道数
    else:
        print("📥 未找到可用权重，将从头开始训练")
        # 对于多模态融合模型，输入通道数可能已经在配置文件中设置
        # 如果需要，可以在这里手动设置输入通道数
        # train_kwargs["ch"] = 6  # 设置输入通道数为6
    
    if not os.path.exists(config_path):
        print("❌ 配置文件不存在，跳过")
        continue
    
    try:
        # 记录当前存在的文件夹（用于检测新创建的）
        before_folders = get_existing_train_folders()
        
        # 创建模型实例
        print(f"🔧 创建模型 {model_name}...")
        
        # 关键：处理多模态融合模型的输入通道问题
        # 方法1: 检查配置文件是否已经设置了正确的输入通道
        try:
            import yaml
            with open(config_path, 'r') as f:
                config_content = yaml.safe_load(f)
            print(f"📄 配置文件内容预览: {config_content.get('ch', '未设置ch参数')}")
        except:
            print("⚠️  无法读取配置文件内容")
        
        # 根据是否有权重来决定如何创建模型
        if weight_to_use and os.path.exists(weight_to_use):
            try:
                print(f"🔄 从权重文件创建模型: {os.path.basename(weight_to_use)}")
                # 从权重文件创建模型，它会自动继承权重中的架构
                model = RTDETR(weight_to_use)
                print("✅ 从权重成功创建模型")
                
                # 如果需要，可以更新训练参数
                # model.args.update(train_kwargs)
                
                # 重要：对于多模态模型，可能需要确保输入通道设置正确
                # 尝试检查模型的输入通道
                try:
                    # 检查模型是否有ch属性
                    if hasattr(model.model, 'ch'):
                        print(f"📊 模型输入通道数: {model.model.ch}")
                    elif hasattr(model, 'args') and hasattr(model.args, 'ch'):
                        print(f"📊 模型输入通道数: {model.args.ch}")
                except:
                    print("⚠️  无法获取模型输入通道信息")
                    
            except Exception as e:
                print(f"⚠️  从权重创建模型失败: {e}")
                print("🔄 尝试从配置文件创建模型...")
                # 方法2: 使用配置文件创建模型
                # 重要：对于多模态融合模型，可能需要在配置文件中设置输入通道
                # 或者通过参数传递
                model = RTDETR(config_path)
                print("✅ 从配置文件创建模型")
                
                # 注意：如果权重和配置文件架构不匹配，加载权重可能会失败
                # 但多模态融合模型通常结构相似，可以尝试
                try:
                    if weight_to_use and os.path.exists(weight_to_use):
                        # 尝试加载权重，但忽略不匹配的参数
                        print("🔄 尝试加载权重...")
                        # 这里使用model.load()方法可能更合适
                        # 但RTDETR的API可能需要特殊处理
                        # 作为备选方案，我们可以直接训练，不加载权重
                        print("⚠️  跳过权重加载，直接训练")
                except Exception as load_error:
                    print(f"⚠️  权重加载失败: {load_error}")
                    print("📥 将从头开始训练")
        else:
            # 从头开始训练
            print("🔄 从头开始创建模型...")
            # 重要：确保多模态融合模型有正确的输入通道设置
            # 配置文件应该已经设置了ch=6
            model = RTDETR(config_path)
            print("✅ 从头创建模型")
        
        # 训练模型 - 关键步骤
        print(f"🚀 开始训练 {model_name}...")
        
        # 添加一些调试信息
        print(f"🔧 训练参数: {train_kwargs}")
        
        # 对于多模态融合模型，可能需要禁用AMP检查
        # 因为AMP检查可能使用默认的3通道模型
        train_kwargs["amp"] = False  # 确保AMP关闭
        
        # 训练模型
        results = model.train(
            data=data_path,
            **train_kwargs
        )
        
        # 训练完成后，检测新创建的文件夹
        after_folders = get_existing_train_folders()
        new_folders = [f for f in after_folders if f not in before_folders]
        
        if new_folders:
            # 找到最新创建的文件夹
            new_folders.sort(key=lambda x: int(x[5:]) if x != "train" and x[5:].isdigit() else 0)
            latest_new_folder = new_folders[-1]
            new_folder_path = os.path.join(RUNS_DIR, latest_new_folder)
            
            print(f"📁 新创建的训练文件夹: {latest_new_folder}")
            
            # 在新文件夹中查找权重文件
            weights_dir = os.path.join(new_folder_path, "weights")
            if os.path.exists(weights_dir):
                # 查找权重文件
                weight_files = [f for f in os.listdir(weights_dir) if f.endswith('.pt')]
                
                # 优先使用best.pt
                best_weight = os.path.join(weights_dir, "best.pt")
                if os.path.exists(best_weight):
                    previous_weight_path = best_weight
                    weight_info = ("best.pt", best_weight)
                elif weight_files:
                    # 使用第一个找到的权重文件
                    first_weight = os.path.join(weights_dir, weight_files[0])
                    previous_weight_path = first_weight
                    weight_info = (weight_files[0], first_weight)
                else:
                    print(f"⚠️  在 {latest_new_folder}/weights 中未找到权重文件")
                    weight_info = None
                
                if weight_info:
                    weight_history.append((model_name, weight_info[1]))
                    print(f"✅ {model_name} 训练完成!")
                    print(f"💾 权重文件: {weight_info[0]}")
                    print(f"📂 完整路径: {weight_info[1]}")
                    print(f"📏 文件大小: {os.path.getsize(weight_info[1])/1024/1024:.1f} MB")
        else:
            # 如果没有检测到新文件夹，尝试使用其他方法查找权重
            print("🔍 未检测到新文件夹，尝试查找权重...")
            # 获取最新的文件夹
            latest_folder = get_latest_train_folder()
            if latest_folder:
                weights_dir = os.path.join(latest_folder, "weights")
                if os.path.exists(weights_dir):
                    # 查找最新的权重文件
                    weight_files = glob.glob(os.path.join(weights_dir, "*.pt"))
                    if weight_files:
                        # 按修改时间排序
                        weight_files.sort(key=os.path.getmtime, reverse=True)
                        latest_weight = weight_files[0]
                        previous_weight_path = latest_weight
                        weight_history.append((model_name, latest_weight))
                        print(f"✅ {model_name} 训练完成!")
                        print(f"💾 找到权重: {os.path.basename(latest_weight)}")
                        print(f"📂 路径: {latest_weight}")
        
        trained_models.append(model_name)
        
    except Exception as e:
        print(f"❌ {model_name} 训练失败: {e}")
        import traceback
        traceback.print_exc()
        
        # 尝试调试：检查模型结构
        if 'model' in locals():
            try:
                print("🔍 模型结构信息:")
                if hasattr(model, 'model'):
                    print(f"  模型类型: {type(model.model)}")
                if hasattr(model, 'args'):
                    print(f"  模型参数: {model.args}")
            except:
                print("⚠️  无法获取模型结构信息")
        
        # 即使训练失败，也尝试查找是否有权重文件生成
        after_folders = get_existing_train_folders()
        new_folders = [f for f in after_folders if f not in before_folders]
        if new_folders:
            print(f"⚠️  训练失败但检测到新文件夹: {new_folders}")

# 输出总结报告
print("\n" + "=" * 70)
print("📋 训练总结报告")
print("=" * 70)

print(f"\n✅ 成功训练的模型 ({len(trained_models)}/{len(model_configs)}):")
for i, model_name in enumerate(trained_models, 1):
    print(f"  {i}. {model_name}")

print(f"\n📁 权重继承历史:")
if weight_history:
    for i, (model_name, weight_path) in enumerate(weight_history):
        if weight_path and os.path.exists(weight_path):
            folder_name = os.path.basename(os.path.dirname(os.path.dirname(weight_path)))
            weight_file = os.path.basename(weight_path)
            print(f"  {i+1}. {model_name}: {folder_name}/weights/{weight_file}")
        else:
            print(f"  {i+1}. {model_name}: 无可用权重")
else:
    print("  ❌ 没有权重历史记录")

print(f"\n📂 所有训练记录保存在: {RUNS_DIR}")
if weight_history:
    last_weight = weight_history[-1][1]
    if os.path.exists(last_weight):
        print(f"📊 最终权重文件: {last_weight}")
        print(f"📦 文件大小: {os.path.getsize(last_weight)/1024/1024:.1f} MB")

# 列出所有训练文件夹
print(f"\n📁 当前训练文件夹列表:")
train_folders = get_existing_train_folders()
train_folders.sort(key=lambda x: int(x[5:]) if x != "train" and x[5:].isdigit() else 0)
for folder in train_folders:
    folder_path = os.path.join(RUNS_DIR, folder)
    weights_dir = os.path.join(folder_path, "weights")
    if os.path.exists(weights_dir):
        weight_files = [f for f in os.listdir(weights_dir) if f.endswith('.pt')]
        print(f"  {folder}: {len(weight_files)} 个权重文件")
    else:
        print(f"  {folder}: 无权重文件")

print("\n🎉 训练流程完成!")