# re.py  (BATCH ONLY + AUTO PICK 3 FEATURE LAYERS + CAM back to original size + big-defect focus)
import os
import shutil
import warnings
warnings.filterwarnings("ignore")

import cv2
import numpy as np
import torch
from PIL import Image

from ultralytics.nn.tasks import attempt_load_weights

from pytorch_grad_cam import GradCAMPlusPlus
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.activations_and_gradients import ActivationsAndGradients


# =========================
# Config (edit here)
# =========================
WEIGHT = "/root/autodl-tmp/mmdetr/runs/v8.pt"
DEVICE = "cuda:0"  # or "cpu"

RGB_DIR = r"/root/autodl-tmp/mmdetr/YYY/image"
IR_DIR  = r"/root/autodl-tmp/mmdetr/YYY/images"

OUT_DIR = "result"
IMG_SIZE = 640

# CAM target: focus on top detections (big defects usually dominate top scores)
TOPK = 1
CLASS_ID = None   # set int if you want a specific defect class, else None
# =========================


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff", ".heic", ".dng", ".mpo", ".pfm"}


def is_image_file(p: str) -> bool:
    return os.path.splitext(p)[1].lower() in IMG_EXTS


def letterbox_with_info(im, new_shape=(640, 640), color=(114, 114, 114)):
    shape = im.shape[:2]  # (h, w)
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))  # (new_w, new_h)

    dw = new_shape[1] - new_unpad[0]
    dh = new_shape[0] - new_unpad[1]
    dw /= 2
    dh /= 2

    if shape[::-1] != new_unpad:
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)

    top = int(round(dh - 0.1))
    bottom = int(round(dh + 0.1))
    left = int(round(dw - 0.1))
    right = int(round(dw + 0.1))

    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    return im, r, (left, top), new_unpad


def patch_pytorch_grad_cam_for_tuple_outputs():
    """Fix: hooked layer output/grad may be tuple/list => pick first tensor"""
    def _first_tensor(x):
        if torch.is_tensor(x):
            return x
        if isinstance(x, (list, tuple)):
            for v in x:
                if torch.is_tensor(v):
                    return v
        return None

    def save_activation(self, module, input, output):
        t = _first_tensor(output)
        if t is None:
            raise TypeError(f"[CAM] Hook output has no tensor. type={type(output)}")
        self.activations.append(t.detach().cpu())

    def save_gradient(self, module, grad_input, grad_output):
        t = _first_tensor(grad_output)
        if t is None and isinstance(grad_output, (list, tuple)) and len(grad_output) > 0:
            t = _first_tensor(grad_output[0])
        if t is None:
            raise TypeError(f"[CAM] Hook grad has no tensor. type={type(grad_output)}")
        self.gradients.insert(0, t.detach().cpu())

    ActivationsAndGradients.save_activation = save_activation
    ActivationsAndGradients.save_gradient = save_gradient


def force_ultralytics_predict_with_grad(ultra_model: torch.nn.Module):
    """Force Ultralytics BaseModel.forward to run grad-enabled predict."""
    if not hasattr(ultra_model, "_predict_once"):
        raise AttributeError("Ultralytics model has no _predict_once; cannot force grad predict.")

    def _predict_with_grad(self, x, *args, **kwargs):
        return self._predict_once(x)

    ultra_model.predict = _predict_with_grad.__get__(ultra_model, type(ultra_model))


def iter_tensors(x):
    """Yield all tensors inside nested tuple/list/dict structures."""
    if torch.is_tensor(x):
        yield x
    elif isinstance(x, dict):
        for v in x.values():
            yield from iter_tensors(v)
    elif isinstance(x, (list, tuple)):
        for v in x:
            yield from iter_tensors(v)


class TopDetScoreTarget:
    """
    CAM target focusing on detections:
    find a [B,N,C] tensor among outputs, then backprop from top-K scores.
    """
    def __init__(self, class_id=None, topk=1):
        self.class_id = class_id
        self.topk = int(topk)

    def __call__(self, model_output):
        candidates = []
        for t in iter_tensors(model_output):
            if t.ndim == 3 and t.shape[-1] >= 2:
                candidates.append(t)
        if not candidates:
            raise TypeError("[CAM Target] No [B,N,C] tensor found in model output.")

        x = sorted(candidates, key=lambda z: z.shape[-1], reverse=True)[0]  # [B,N,C]
        scores = x.sigmoid()

        if self.class_id is None:
            qscore = scores.max(dim=-1).values   # [B,N]
        else:
            cid = int(self.class_id)
            cid = max(0, min(cid, scores.shape[-1] - 1))
            qscore = scores[..., cid]            # [B,N]

        k = max(1, min(self.topk, qscore.shape[1]))
        topk_vals = torch.topk(qscore, k=k, dim=1).values  # [B,k]
        return topk_vals.mean()


def find_decoder_from_indices(model: torch.nn.Module):
    """
    Try to find RTDETRDecoder module inside model.model and return its 'from' indices if possible.
    Works for many Ultralytics-like models where modules are in model.model.
    """
    if not hasattr(model, "model"):
        return None

    mm = model.model
    # The last module is often a head/decoder
    for i in range(len(mm)-1, -1, -1):
        m = mm[i]
        name = m.__class__.__name__.lower()
        if "rtdetrdecoder" in name or "decoder" in name:
            f = getattr(m, "f", None)  # Ultralytics keeps "from" in .f often
            if isinstance(f, (list, tuple)) and len(f) >= 3:
                return i, list(f)
    return None


def pick_3_layers_for_cam(model: torch.nn.Module):
    """
    Auto-pick 3 layers:
    1) If decoder has .f (from) indices, use those (best)
    2) else fallback to last 3 Conv/Conv2d modules in model.model
    Returns list of (tag, module)
    """
    picked = []

    dec = find_decoder_from_indices(model)
    if dec is not None:
        dec_idx, f = dec
        # many RTDETR heads take 3 features
        f3 = f[:3]
        for idx in f3:
            if idx < 0:
                idx = len(model.model) + idx
            picked.append((f"L{idx}", model.model[idx]))
        return picked

    # fallback: last 3 conv-like blocks in model.model
    if not hasattr(model, "model"):
        raise AttributeError("Model has no attribute 'model' to auto-pick layers.")

    conv_like = []
    for i, m in enumerate(model.model):
        n = m.__class__.__name__.lower()
        if "conv" in n:  # includes Conv, Conv2d, ConvNormLayer...
            conv_like.append((i, m))

    if len(conv_like) >= 3:
        last3 = conv_like[-3:]
        for idx, m in last3:
            picked.append((f"L{idx}", m))
        return picked

    # ultimate fallback: last Conv2d in whole model
    last_conv2d = None
    for m in model.modules():
        if isinstance(m, torch.nn.Conv2d):
            last_conv2d = m
    if last_conv2d is None:
        raise RuntimeError("Cannot find conv layers for CAM.")
    return [("lastconv", last_conv2d)]


class MultiModalCAMBatch:
    def __init__(self, weight: str, device: str, img_size: int = 640):
        self.device = torch.device(device)
        self.img_size = img_size

        print(f"[info] loading weight: {weight}")
        self.model = attempt_load_weights(weight, device=self.device, inplace=True, fuse=True)
        self.model.eval()

        force_ultralytics_predict_with_grad(self.model)
        for p in self.model.parameters():
            p.requires_grad_(True)

        patch_pytorch_grad_cam_for_tuple_outputs()

        self.layer_pairs = pick_3_layers_for_cam(self.model)
        print("[info] CAM layers:")
        for tag, m in self.layer_pairs:
            print(f"  - {tag}: {m.__class__.__name__}")

        self.targets = [TopDetScoreTarget(class_id=CLASS_ID, topk=TOPK)]

        # create one CAM object per layer
        self.cams = {}
        for tag, layer in self.layer_pairs:
            self.cams[tag] = GradCAMPlusPlus(
                model=self.model,
                target_layers=[layer],
                use_cuda=str(self.device).startswith("cuda"),
            )

    @staticmethod
    def _read_image(path: str, tag: str):
        img = cv2.imread(path)
        if img is None:
            raise FileNotFoundError(f"[{tag}] cv2.imread failed\npath={path}\nexists={os.path.exists(path)}")
        return img

    def _build_input_tensor(self, rgb_bgr: np.ndarray, ir_bgr: np.ndarray):
        h0, w0 = rgb_bgr.shape[:2]

        rgb_lb, _, (pad_x, pad_y), (new_w, new_h) = letterbox_with_info(rgb_bgr, (self.img_size, self.img_size))
        ir_lb,  _, (_, _), _ = letterbox_with_info(ir_bgr,  (self.img_size, self.img_size))

        rgb = cv2.cvtColor(rgb_lb, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        ir  = cv2.cvtColor(ir_lb,  cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0

        cat = np.concatenate([rgb, ir], axis=2)  # (S,S,6)
        input_tensor = torch.from_numpy(cat.transpose(2, 0, 1)).unsqueeze(0).to(self.device)

        rgb_orig_float = cv2.cvtColor(rgb_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        return input_tensor, (pad_x, pad_y), (new_w, new_h), (h0, w0), rgb_orig_float

    def run_one_pair(self, rgb_path: str, ir_path: str, out_base: str):
        rgb_bgr = self._read_image(rgb_path, "RGB")
        ir_bgr  = self._read_image(ir_path,  "IR")

        input_tensor, (pad_x, pad_y), (new_w, new_h), (h0, w0), rgb_orig_float = self._build_input_tensor(rgb_bgr, ir_bgr)

        for tag, cam in self.cams.items():
            with torch.enable_grad():
                cam_lb = cam(input_tensor, targets=self.targets)[0]  # (S,S)

            # remove padding -> (new_h,new_w)
            cam_crop = cam_lb[pad_y:pad_y + new_h, pad_x:pad_x + new_w]
            # resize to original -> (h0,w0)
            cam_orig = cv2.resize(cam_crop, (w0, h0), interpolation=cv2.INTER_LINEAR)

            cam_img = show_cam_on_image(rgb_orig_float, cam_orig, use_rgb=True)

            out_path = f"{out_base}_cam_{tag}.png"
            os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
            Image.fromarray(cam_img).save(out_path)

    def run_batch(self, rgb_dir: str, ir_dir: str, out_dir: str):
        if os.path.exists(out_dir):
            shutil.rmtree(out_dir)
        os.makedirs(out_dir, exist_ok=True)

        names = sorted(os.listdir(rgb_dir))
        processed = 0
        missing = 0
        skipped = 0
        errored = 0

        for name in names:
            p_rgb = os.path.join(rgb_dir, name)
            if (not os.path.isfile(p_rgb)) or (not is_image_file(p_rgb)):
                skipped += 1
                continue

            p_ir = os.path.join(ir_dir, name)
            if not os.path.exists(p_ir):
                print(f"[miss] IR not found for {name}: {p_ir}")
                missing += 1
                continue

            base = os.path.splitext(name)[0]
            out_base = os.path.join(out_dir, base)

            try:
                self.run_one_pair(p_rgb, p_ir, out_base)
                processed += 1
                if processed % 10 == 0:
                    print(f"[prog] processed={processed}, missing={missing}, skipped={skipped}, errored={errored}")
            except Exception as e:
                errored += 1
                print(f"[err] {name}: {e}")

        print(f"[done] processed={processed}, missing_pairs={missing}, skipped_non_images={skipped}, errored={errored}")


if __name__ == "__main__":
    cam = MultiModalCAMBatch(
        weight=WEIGHT,
        device=DEVICE,
        img_size=IMG_SIZE,
    )
    cam.run_batch(RGB_DIR, IR_DIR, OUT_DIR)
